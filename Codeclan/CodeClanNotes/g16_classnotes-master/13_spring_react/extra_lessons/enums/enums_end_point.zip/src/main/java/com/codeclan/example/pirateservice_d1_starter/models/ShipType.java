package com.codeclan.example.pirateservice_d1_starter.models;

public enum ShipType {
    GALLEON,
    DREADNOUGHT,
    CUTTER,
    SCHOONER
}
