#Devise

###Pre-Requisites
 - Authentication_introduction.md
 - Auth play project from Authentication introduction.

###Learning Objectives
 - Show implementing a session based authentication system using Devise

##Introduction
We are going to implement a session based authentication system in Rails.  To do this we are going to use a popular Gem called Devise.

Before we follow the devise install instructions, let's think about what we will need following our earlier discussion.

Signing Up.  Somewhere to store the details of the users who are signing up.  
  User table - username, password.
  Password will be encrypted,  never wise to store plaintext passwords.  Can discuss one way hashing algorithm, quick one way, hard the other. EG multiplication and factoring.

#Installing Devise.

  Let's follow the instructions on the devise github to get it setup.
  https://github.com/plataformatec/devise

  ```
  #Gemfile
  gem 'devise'

  #Terminal
  bundle install
  rails generate devise:install

  #Terminal
  rails generate devise User
  rake routes
  rake db:migrate
  ```

  ```
  // accounts_controller.rb

  before_action :authenticate_user!
  ```

  Devise automatically provides a sign_in sign_up form. If we try to go to //acounts it will redirect us to the sign in page. Since we only specified that we would respond with json the app is now crashing. We should add html.

  ```
  //application_controller.rb

  respond_to :json, :html
  ```

  Try and get our protected resource.  Okay we need to get our passcard, session cookie!

  It does give us a form to sign up and log in.
  http://localhost:3000/users/sign_up

  Let's sign in and then return to   http://localhost:3000/accounts

  Go to resources/cookies and we will see our cookie.  Delete this and we lose our pass.

##Lab
Currently we get all the accounts when we get accounts. Alter the application so that accounts belong to users and we only get the accounts for the user who is logged in.

terminal

```
rails g model Account name:text amount:decimal user:references

rake db:migrate
```

And let's tell the User model that a User has many accounts.


```
  //app/models/user.rb

  has_many :accounts
```

```
//seeds.rb

User.destroy_all
Account.destroy_all

user_one = User.create!({email: 'jay@gmail.com', password:'password', password_confirmation:'password'})
user_two = User.create!({email: 'rick@gmail.com', password:'password', password_confirmation:'password'})

user_one.accounts.create({name:'local', amount:100.00})

user_two.accounts.create({name:'local', amount:0.01});
user_two.accounts.create({name:'Guernsey Marketing', amount:100000.01});
```

//accounts_controller

```
  def index
    authenticate_user!
    @accounts = current_user.accounts
    render( { json: @accounts } )
  end
```

```
respond_to do |format|
  format.json { render json: accounts }
end
```