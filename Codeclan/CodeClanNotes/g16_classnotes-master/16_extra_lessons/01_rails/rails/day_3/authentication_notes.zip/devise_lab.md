#Authentication Lab

##Learning objectives
 - Practice using devise

##Task

Create a Fantasy football rails application that:
 - You can sign up with
 - You can sign in with
 - User will have a one to many relationship with players. 
 - Using seed. Add Players to your account. Players will have a name, age and their current team. 
 - Hitting localhost:3000/players will return all the players associated with your account if you are logged in.
 - Don't worry about signing up / signing in having no players associated with it.

