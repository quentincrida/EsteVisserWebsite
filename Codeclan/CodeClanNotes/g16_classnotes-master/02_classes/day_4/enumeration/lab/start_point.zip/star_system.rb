class StarSystem
  attr_reader :name, :planets

    
end
