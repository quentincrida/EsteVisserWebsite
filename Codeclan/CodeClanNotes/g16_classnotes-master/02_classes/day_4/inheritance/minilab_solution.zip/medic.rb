require_relative('person')

class Medic < Person

  def heal
    return "I can heal people"
  end
end