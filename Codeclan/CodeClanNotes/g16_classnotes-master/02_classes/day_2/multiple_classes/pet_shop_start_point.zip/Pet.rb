class Pet
  attr_reader :name, :breed, :type, :price

  def initialize(name, type, breed, price)
    @name = name
    @type = type
    @breed = breed
    @price = price
  end

end
