class Food

  attr_reader :name, :price, :rejuvination_level

  def initialize(name, price, rejuvination_level)
    @name = name
    @price = price
    @rejuvination_level = rejuvination_level
  end

end
